export const apiData = (res) => {
    return {
        type: "APIDATA",
        data: res
    }
}
export const FutureDate = (res) => {
    return {
        type: "FUTUREDATE",
        data: res
    }
}